package com.example.tugas2navigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
