class Datepicker {
  String title;
  String name;
  int price;

  Datepicker({
    required this.title,
    required this.name,
    required this.price,
  });
}
var getData = [
  Datepicker(
    title: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQEaqpldc_YOWM8YIRERiXdb5y6D2S1SyP4mw&usqp=CAU",
    name: "Jam Dinding",
    price: 350000,
  ),
  Datepicker(
    title: "https://images.tokopedia.net/img/cache/500-square/VqbcmM/2021/7/22/220cae87-81df-458f-83f7-7b0d9ec773fe.jpg",
    name: "Jam Weker",
    price: 50000,
  ),
  Datepicker(
    title: "https://images.tokopedia.net/img/cache/500-square/hDjmkQ/2021/1/23/f3bb40c8-1eb1-4be0-a5c2-601e73cc68d3.jpg",
    name: "Jam Tangan",
    price: 120000,
  ),
  Datepicker(
    title:
    "https://images.tokopedia.net/img/cache/500-square/hDjmkQ/2021/3/22/ac25d45e-22f8-48d6-a081-90a18398a848.jpg",
    name: "Smartwatch",
    price: 520000,
  ),
];
